package com.br.SuplaMent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuplaMentApplicationTests {

	@Test
	void contextLoads() {
	}

}
