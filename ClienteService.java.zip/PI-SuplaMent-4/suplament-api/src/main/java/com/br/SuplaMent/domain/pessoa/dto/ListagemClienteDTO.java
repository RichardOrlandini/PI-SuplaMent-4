//package com.br.SuplaMent.domain.pessoa.dto;
//
//import com.br.SuplaMent.domain.cliente.Cliente;
//
//
//public record ListagemClienteDTO(Long id, Boolean ativo, String nome, String email) {
//
//        public ListagemClienteDTO(Cliente cliente) {
//            this(cliente.getId(), cliente.getActive() , cliente.getNome(), cliente.getEmail());
//        }
//    }
