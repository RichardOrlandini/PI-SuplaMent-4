package com.br.SuplaMent.utils.enums;

public enum StatusPedido {
    AGUARDANDO_PAGAMENTO
}
