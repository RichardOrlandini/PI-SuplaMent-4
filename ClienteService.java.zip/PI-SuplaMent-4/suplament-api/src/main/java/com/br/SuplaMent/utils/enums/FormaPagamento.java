package com.br.SuplaMent.utils.enums;

import java.io.Serializable;

public enum FormaPagamento implements Serializable {
    PIX, BOLETO, CARTAO_DE_CREDITO
}
