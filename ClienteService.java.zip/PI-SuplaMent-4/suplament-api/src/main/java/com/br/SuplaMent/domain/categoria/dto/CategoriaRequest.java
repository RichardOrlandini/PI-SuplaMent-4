package com.br.SuplaMent.domain.categoria.dto;

import lombok.Data;

@Data
public class CategoriaRequest {

    private String descricao;
}
