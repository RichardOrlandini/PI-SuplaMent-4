package com.br.SuplaMent.domain.endereco.dto;

public record DtoEndereco() {
}
