package com.br.SuplaMent.utils.navigation.core;

import java.util.Map;

public interface IAuthFactory {
    Map<String, Object> authContextParams();
}