package com.br.SuplaMent.infra.security.interceptor;

import java.util.List;

public class Urls {
//    public static final List<String> PROTECTED_URLS = List.of(
//            "api/produto",
//            "api/fornecedor",
//            "api/categoria"
//    );
    public static final List<String> PROTECTED_URLS = List.of(
            "api/categoria/admin"
    );
}
