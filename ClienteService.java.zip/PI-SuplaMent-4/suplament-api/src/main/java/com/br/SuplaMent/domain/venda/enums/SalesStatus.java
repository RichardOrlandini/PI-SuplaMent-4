package com.br.SuplaMent.domain.venda.enums;

public enum SalesStatus {

    APROVADA,
    REJEITADA
}
