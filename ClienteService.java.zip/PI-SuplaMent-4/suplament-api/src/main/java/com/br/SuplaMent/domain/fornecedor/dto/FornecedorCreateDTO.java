package com.br.SuplaMent.domain.fornecedor.dto;

import lombok.Data;

@Data
public class FornecedorCreateDTO {

    private String nome;
}
