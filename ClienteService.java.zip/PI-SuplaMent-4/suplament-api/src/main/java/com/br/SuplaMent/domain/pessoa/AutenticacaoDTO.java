package com.br.SuplaMent.domain.pessoa;

public record AutenticacaoDTO(String email, String senha) {
}
