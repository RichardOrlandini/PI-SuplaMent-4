package com.br.SuplaMent.domain.pedido.dto;

public record AvisoRetornoPedidoDTO(Long id, Double valor, String mensagem) {
}
