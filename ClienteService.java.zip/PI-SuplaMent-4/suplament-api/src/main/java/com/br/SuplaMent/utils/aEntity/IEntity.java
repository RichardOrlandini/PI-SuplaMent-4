package com.br.SuplaMent.utils.aEntity;

public interface IEntity {
}