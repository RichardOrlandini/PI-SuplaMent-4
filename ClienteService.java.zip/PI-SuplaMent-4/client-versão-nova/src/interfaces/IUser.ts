export interface IUser {
    nome: string;
    role: string;
    email: string;
    senha: string;
}