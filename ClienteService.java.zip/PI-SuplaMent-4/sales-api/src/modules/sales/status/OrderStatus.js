export const PENDING = "PENDENTE";
export const APPROVED = "APROVADO";
export const REJECTED = "REJEITADO";
