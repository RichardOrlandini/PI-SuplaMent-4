export default {
    COLORS: {
        BACKGROUND_900: "#232129",
        BACKGROUND_800: "#312E38",
        BACKGROUND_700: "#3E3B47",

        // BACKGROUND_900: "#A9A9A9",
        // BACKGROUND_800: "#A9A9A9",
        // BACKGROUND_700: "#FFDEAD",

        WHITE: "#F4EDE8",
        ORANGE: "#FF9000",
    
        GRAY_100: "#999591",
        GRAY_300: "#666360",
    
        RED: "#FF002E"
      }
};