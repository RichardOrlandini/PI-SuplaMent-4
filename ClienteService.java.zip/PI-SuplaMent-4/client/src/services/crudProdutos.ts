export async function GET_PRODUTOS(): Promise<IProduto[]> {
}
export async function SHOW_PRODUTOS(id: number): Promise<IProduto> {
}