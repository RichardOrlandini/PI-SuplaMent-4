


export function Error404Container() {

    return (
        <>
            ERRO pagina não encontrada!
        </>
    )
}