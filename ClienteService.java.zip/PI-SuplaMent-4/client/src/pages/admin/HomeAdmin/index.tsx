// import { Footer } from "../../../components/Footer";
// import { Box, Button, Typography, AppBar, Container, Toolbar, Link, Paper } from "@mui/material"
// import { Link as RouterLink, Outlet } from 'react-router-dom'
// import { Header } from "../../../components/Header"
// import { PageHeaderAdmin } from "../PageHeaderAdmin";


// export function HomeAdmin() {

//     return (
//         <>
//             <Header />

//             <Box sx={{ marginTop: 5 }}>

//                 <Typography variant="h5" sx={{ marginLeft: 3 }}>
//                     Areá Administrativa
//                 </Typography>

//             </Box>



//             <PageHeaderAdmin/>

//             <Box>
//                 <Container maxWidth="lg" sx={{ mt: 1 }}>
//                     <Paper sx={{ p: 2 }}>
//                         <Outlet />
//                     </Paper>
//                 </Container>
//             </Box>

//             <Footer />
//         </>
//     )
// }