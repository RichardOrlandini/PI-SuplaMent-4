


export interface IParametrosBusca {
    ordering?: string;
    search?: string;
    nome?: string;
}