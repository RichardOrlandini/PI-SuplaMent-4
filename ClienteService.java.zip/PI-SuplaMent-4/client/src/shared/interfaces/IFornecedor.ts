
export default interface IFornecedor {
    id: number;
    nome: string;
}