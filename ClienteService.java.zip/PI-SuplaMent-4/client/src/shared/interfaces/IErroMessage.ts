

export interface IErroMessage {
    campo: string;
    mensagem: string;
}