
export default interface ICategoria {
  id: number;
  descricao: string;
}