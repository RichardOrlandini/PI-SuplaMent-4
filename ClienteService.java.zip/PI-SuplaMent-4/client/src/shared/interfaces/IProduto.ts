export interface IProduto {
    id: number;
    active?: boolean;
    nome: string;
    descri?: string;
    valor: string;
    qtd: string;
    nomeImagem?: string;
}


